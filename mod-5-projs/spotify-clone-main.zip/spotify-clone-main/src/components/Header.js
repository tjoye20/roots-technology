import React from 'react';
const Header = () => {
    return <h1 className="main-heading">Spotify Music Search</h1>;
};
export default Header;