import React from 'react'

export function Footer() {
    return (
        <div className='border' style={{ height: '80px' }}>
            Footer
        </div>
    )
}
