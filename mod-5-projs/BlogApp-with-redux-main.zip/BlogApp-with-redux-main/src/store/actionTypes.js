const types = {

        START : 'START',

        GET_BLOGS_SUCCESS: 'GET_BLOGS_SUCCESS',
        GET_BLOGS_FAILURE: 'GET_BLOGS_FAILURE',

        ERROR: 'ERROR',

    }

export default types;