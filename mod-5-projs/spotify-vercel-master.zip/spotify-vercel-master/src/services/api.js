import Spotify from 'spotify-web-api-js'


const api = new Spotify()
export default api

